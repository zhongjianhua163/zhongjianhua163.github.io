
((root) => {
  root.dy = { followings: [], living: [] };
  root.dy.getCookies = function () {
    let ret = "";
    chrome.cookies.getAll({ domain: 'douyin.com' }, (cookies) => {
      cookies.forEach((cookie) => {
        ret += cookie.name + "=" + cookie.value + ";";
      });
    });
    return ret;
  };

  root.dy.getFollowings = async function () {
    try {
      let response = await fetch("https://live.douyin.com/aweme/v1/web/im/spotlight/relation/?with_fstatus=1", {
        method: "GET",
        headers: {
          "Cookie": root.dy.getCookies()
        }
      });

      if (response.status != 200) {
        return [];
      }

      let data = await response.json();
      return data.followings ?? [];
    } catch (e) {
      console.log(e);
      return [];
    }
  };

  root.dy.feedFollow = async function () {
    let url = "https://www.douyin.com/webcast/web/feed/follow/?device_platform=webapp&aid=6383&channel=channel_pc_web&scene=aweme_pc_follow_top";
    try {
      let response = await fetch(url, {
        method: "GET",
        headers: {
          "Cookie": root.dy.getCookies()
        }
      });

      if (response.status != 200) {
        return null;
      }

      let data = await response.json();
      return data.data.data ?? [];
    } catch (e) {
      console.log(e);
      return null;
    }
  }

})(this);

((root) => {
  root.ks = { followings: [], living: [] };
  root.ks.getCookies = function () {
    let ret = "";
    chrome.cookies.getAll({ domain: 'kuaishou.com' }, (cookies) => {
      cookies.forEach((cookie) => {
        ret += cookie.name + "=" + cookie.value + ";";
      });
    });
    return ret;
  };

  root.ks.getFollowings = async function () {
    try {
      let response = await fetch("https://live.kuaishou.com/live_api/follow/all", {
        method: "GET",
        headers: {
          "Cookie": root.ks.getCookies()
        }
      });

      if (response.status != 200) {
        return null;
      }

      let data = await response.json();
      return data.data.list ?? [];
    }
    catch (e) {
      console.log(e);
      return null;
    }
  }

  root.ks.getLiving = async function () {
    try {
      let response = await fetch("https://live.kuaishou.com/live_api/follow/living", {
        method: "GET",
        headers: {
          "Cookie": root.ks.getCookies()
        }
      });

      if (response.status != 200) {
        return null;
      }

      let data = await response.json();
      return data.data.list ?? [];
    }
    catch (e) {
      console.log(e);
      return null;
    }
  }
})(this);

((root) => {
  root.hy = { followings: [], living: [] };
  root.hy.getCookies = function () {
    let ret = "";
    chrome.cookies.getAll({ domain: 'huya.com' }, (cookies) => {
      cookies.forEach((cookie) => {
        ret += cookie.name + "=" + cookie.value + ";";
      });
    });
    return ret;
  };

  root.hy.getSubscribe = async function () {
    try {
      let response = await fetch("https://live.huya.com/liveHttpUI/getUserSubscribeToInfoList?iPageIndex=0&_=" + new Date().getTime(), {
        method: "GET",
        headers: {
          "Cookie": root.ks.getCookies()
        }
      });

      if (response.status != 200) {
        return null;
      }

      let data = await response.json();
      return data.vItems ?? [];
    }
    catch (e) {
      console.log(e);
      return null;
    }
  }
})(this);

((root) => {
  root.bz = { followings: [], living: [] };
  root.bz.getCookies = function () {
    let ret = "";
    chrome.cookies.getAll({ domain: 'bilibili.com' }, (cookies) => {
      cookies.forEach((cookie) => {
        ret += cookie.name + "=" + cookie.value + ";";
      });
    });
    return ret;
  };

  root.bz.getFollowings = async function () {
    try {
      let response = await fetch("https://api.live.bilibili.com/xlive/web-ucenter/user/following?page=1&page_size=20&ignoreRecord=1&hit_ab=true", {
        method: "GET",
        headers: {
          "Cookie": root.bz.getCookies()
        }
      })

      if (response.status != 200) {
        return null;
      }

      let data = await response.json();
      return data.data.list ?? [];
    }
    catch (e) {
      console.log(e);
      return null;
    }
  }
})(this);

var lastRefresh = 0;
var lastRefreshFollowings = 0;
var lastCount = 0;

function sendMessageToContentScript(message) {
  chrome.tabs.query({}, (ts) => {
    ts.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, message, (response) => {
        if (chrome.runtime.lastError) {
          //console.error(chrome.runtime.lastError.message);
          // 应该是没注入content.js
        }
      });
    });
  });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("onMessage:", message);
  if (message.action === "getLiving") {
    sendResponse({ action: "living", living: { dy: this.dy.living, ks: this.ks.living, hy: this.hy.living, bz: this.bz.followings } });
  }
  else if (message.action == "getFollowings") {
    lastRefreshFollowings = 0;
    sendResponse({ action: "followings", followings: { dy: this.dy.followings, ks: this.ks.followings, hy: this.hy.followings, bz: this.bz.followings } });
  }
  else if (message.action == "storage") {
    chrome.storage.local.get(message.storage, (fls) => {
      sendResponse({ action: "storage", storage: fls || {} });
    });
    return true;// 异步回复，必须先返回true，否则连接会被释放
  }
  else if (message.action == "refreshLivings") {
    sendMessageToContentScript({ action: "living", living: { dy: this.dy.living, ks: this.ks.living, hy: this.hy.living, bz: this.bz.followings } });
  }
});

async function query_task() {
  let t = new Date().getTime();
  if (lastRefresh + 20000 < t) {
    lastRefresh = t;// 每20秒拉取一次

    try {
      if (lastRefreshFollowings + 3600000 < t // 一小时更新一次
        || this.dy.followings.length == 0
        || this.ks.followings.length == 0) {
        lastRefreshFollowings = t;
        Promise.all([this.dy.getFollowings(), this.ks.getFollowings()]).then(([dyResult, ksResult]) => {
          this.dy.followings = dyResult;
          this.ks.followings = ksResult;
        });
      }

      Promise.all([this.dy.feedFollow(), this.ks.getLiving(), this.hy.getSubscribe(), this.bz.getFollowings()]).then(([dyResult, ksResult, hyResult, bzResult]) => {
        this.dy.living = dyResult;
        this.ks.living = ksResult;
        this.hy.living = hyResult;
        this.hy.followings = hyResult;
        this.bz.followings = bzResult;
        this.bz.living = bzResult;
        sendMessageToContentScript({ action: "living", living: { dy: this.dy.living, ks: this.ks.living, hy: this.hy.living, bz: this.bz.followings } });
      });
    }
    catch (e) {
      console.log(e);
    }
  }

  try {
    // 取虎牙开播数量
    let hyLivingCount = 0;
    this.hy.living.forEach(item => {
      if (item.iIsLive == 1) {
        hyLivingCount++;
      }
    });

    // 取B站开播数量
    let bzLivingCount = 0;
    this.bz.followings?.forEach(item => {
      if (item.live_status == 1) {
        bzLivingCount++;
      }
    });

    let count = (this.dy.living?.length ?? 0) + (this.ks.living?.length ?? 0) + hyLivingCount + bzLivingCount;
    if (lastCount != count) {
      lastCount = count;
      chrome.action.setBadgeText({ text: (count > 0 ? count.toString() : '') });
      chrome.action.setBadgeBackgroundColor({ color: '#00FF00' });
    }
  }
  catch (e) {
    console.log(e);
  }
}

query_task();
setInterval(query_task, 1000);