function createList(id, list, followingsStatus) {
    let followingsList = document.getElementById(id);
    if (list.length != 0) {
        followingsList.innerHTML = '';
    }
    else {
        followingsList.innerHTML = '你还没有关注任何主播哦';
    }


    list.forEach(item => {
        let listItem = document.createElement('div');
        listItem.className = 'list-item';
        listItem.id = item.id;

        // 判断是否正在直播
        let avatarText = null;
        if (item.living) {
            avatarText = document.createElement('div');
            avatarText.className = 'living-Text';
            avatarText.textContent = '直播中';

            listItem.title = `${item.nickname}\r\n${item.title}\r\n${item.watchingCount}`;
        }

        let avatarContainer = document.createElement('div');
        avatarContainer.className = 'avatar-container';
        avatarContainer.addEventListener('click', () => {
            window.open(item.url, '_blank');
        });

        let avatar = document.createElement('img');
        avatar.src = item.avatar;
        avatar.className = 'avatar' + (item.living ? " living" : "");

        let details = document.createElement('div');
        details.className = 'details';

        let nickname = document.createElement('div');
        nickname.className = 'nickname';
        nickname.textContent = item.nickname;
        nickname.addEventListener('click', () => {
            window.open(item.url, '_blank');
        });

        let signature = document.createElement('div');
        signature.textContent = item.description;

        let toggleButton = document.createElement('button');
        let status = followingsStatus[item.sdid];
        if (status && status == 'disabled') {
            toggleButton.className = 'toggle-button disabled';
            toggleButton.textContent = '提示';
        }
        else {
            toggleButton.className = 'toggle-button enabled';
            toggleButton.textContent = '已提示';
        }

        toggleButton.addEventListener('click', () => {
            if (toggleButton.classList.contains('disabled')) {
                toggleButton.classList.remove('disabled');
                toggleButton.classList.add('enabled');
                toggleButton.textContent = '已提示';
                followingsStatus[item.sdid] = 'enabled';
            } else {
                toggleButton.classList.remove('enabled');
                toggleButton.classList.add('disabled');
                toggleButton.textContent = '提示';
                followingsStatus[item.sdid] = 'disabled';
            }
            chrome.storage.local.set({ followingsStatus });
            chrome.runtime.sendMessage({ action: "refreshLivings" });
        });

        details.appendChild(nickname);
        details.appendChild(signature);
        avatarContainer.appendChild(avatar);
        if (avatarText) {
            avatarContainer.appendChild(avatarText);
        }
        listItem.appendChild(avatarContainer)

        listItem.appendChild(details);
        listItem.appendChild(toggleButton);
        followingsList.appendChild(listItem);
    });
}

function createDyList(followings, living, followingsStatus, outLiving) {
    let allFollowings = [...followings];

    // 筛选出正在直播的关注者
    let liveFollowings = allFollowings.filter(following => {
        return living.some(item => item.room.owner.sec_uid == following.sec_uid);
    });

    // 筛选出未直播的关注者
    let offlineFollowings = allFollowings.filter(following => !liveFollowings.includes(following));

    // 合并两个数组，直播的在前
    let sortedFollowings = [...liveFollowings, ...offlineFollowings];
    let followingsList = [];


    sortedFollowings.forEach(following => {
        let info = {};

        info.id = following.sec_uid;
        info.sdid = 'dy_' + following.sec_uid;
        info.nickname = following.nickname;
        info.description = following.signature;
        info.avatar = following.avatar_thumb.url_list[0];
        info.title = '';
        info.url = `https://www.douyin.com/user/` + following.sec_uid;
        info.watchingCount = '';
        info.living = false;

        // 判断是否正在直播
        living.find(item => {
            if (item.room.owner.sec_uid == following.sec_uid) {
                info.nickname = '抖音: ' + info.nickname;
                info.url = `https://live.douyin.com/` + item.web_rid;
                info.title = item.room.title;
                info.watchingCount = item.room.room_view_stats.display_long_anchor;
                info.living = true;

                outLiving.push(info);
                return true;
            }
        });

        followingsList.push(info);
    });

    createList('tab_dy', followingsList, followingsStatus);
}

function createKsList(followings, living, followingsStatus, outLiving) {
    let sortedFollowings = [];

    // 先将两个数组统一格式并合并
    living.forEach(item => {
        let info = {
            id: item.author.id,
            sdid: 'ks_' + item.author.id,
            nickname: '快手: ' + item.author.name,
            description: item.author.description,
            avatar: item.author.avatar,
            title: item.caption,
            watchingCount: item.watchingCount,
            living: true,
            url: 'https://live.kuaishou.com/u/' + item.author.id
        }
        sortedFollowings.push(info);
        outLiving.push(info);
    })

    followings.forEach(item => {
        let info = {
            id: item.id,
            sdid: 'ks_' + item.id,
            nickname: item.name,
            description: item.description,
            avatar: item.avatar,
            title: '',
            watchingCount: 0,
            living: false,
            url: 'https://live.kuaishou.com/profile/' + item.id
        };
        sortedFollowings.push(info);
    });

    createList('tab_ks', sortedFollowings, followingsStatus);
}

function createHyList(followings, living, followingsStatus, outLiving) {
    let sortedFollowings = [];
    living.forEach(item => {
        if (item.lUid == 0) {
            return;
        }

        let info = {
            id: item.lUid,
            sdid: 'hy_' + item.lUid,
            nickname: (item.iIsLive == 1 ? '虎牙: ' : '') + item.sNick ?? '',
            description: item.sDescription ?? '',
            avatar: item.sAvatar ?? '#',
            title: item.sLiveDesc ?? '',
            watchingCount: item.iAttendeeCount + '人气',
            living: item.iIsLive == 1,
            url: 'https://www.huya.com/' + item.iRoomId ?? ''
        }
        sortedFollowings.push(info);
        if (item.iIsLive == 1) {
            outLiving.push(info);
        }
    });

    createList('tab_hy', sortedFollowings, followingsStatus);
}

function createBzList(followings, living, followingsStatus, outLiving) {
    let sortedFollowings = [];
    followings.forEach(item => {
        if (item.uid == 0) {
            return;
        }

        let info = {
            id: item.uid,
            sdid: 'bz_' + item.uid,
            nickname: (item.live_status == 1 ? 'B站: ' : '') + item.uname ?? '',
            description: item.room_news,
            avatar: item.face,
            title: item.title,
            watchingCount: '',
            living: item.live_status == 1,
            url: 'https://live.bilibili.com/' + item.roomid
        };

        sortedFollowings.push(info);
        if (item.live_status == 1) {
            outLiving.push(info);
        }
    });

    createList('tab_bz', sortedFollowings, followingsStatus);
}

function createHeaderLiving(followingsStatus, dyOutLiving, ksOutLiving, hyOutLiving, bzOutLiving) {
    let divLiving = document.getElementById("divLiving");
    let html = "";

    if (followingsStatus["mainSwitch"] != 'disabled') {
        let showCount = 7;
        try {
            !dyOutLiving || dyOutLiving.forEach(item => {
                if (showCount <= 0) {
                    return;
                }
                showCount--;

                let sdid = 'dy_' + item.id;
                if (followingsStatus[sdid] == 'disabled') {
                    return;
                }

                html += `<a class="avatar-item" title="${item.nickname}\r\n${item.title}\r\n${item.watchingCount}" href="${item.url}" target="_blank">`;
                html += `<img src="${item.avatar}" >`;
                html += `<div class="avatar-item-text">直播中</div>`;
                html += `</a>`;
            });
        }
        catch (e) {
            console.log(e);
        }

        try {
            !ksOutLiving || ksOutLiving.forEach(item => {
                if (showCount <= 0) {
                    return;
                }
                showCount--;

                let sdid = 'ks_' + item.id;
                if (followingsStatus[sdid] == 'disabled') {
                    return;
                }

                html += `<a class="avatar-item" title="${item.nickname}\r\n${item.title}\r\n${item.watchingCount}" href="${item.url}" target="_blank">`;
                html += `<img src="${item.avatar}" >`;
                html += `<div class="avatar-item-text">直播中</div>`;
                html += `</a>`;
            });
        }
        catch (e) {
            console.log(e);
        }

        try {
            !hyOutLiving || hyOutLiving.forEach(item => {
                if (showCount <= 0) {
                    return;
                }
                showCount--;

                let sdid = 'hy_' + item.id;
                if (followingsStatus[sdid] == 'disabled') {
                    return;
                }

                html += `<a class="avatar-item" title="${item.nickname}\r\n${item.title}\r\n${item.watchingCount}" href="${item.url}" target="_blank">`;
                html += `<img src="${item.avatar}" >`;
                html += `<div class="avatar-item-text">直播中</div>`;
                html += `</a>`;
            })
        }
        catch (e) {
            console.log(e);
        }

        try {
            !bzOutLiving || bzOutLiving.forEach(item => {
                if (showCount <= 0) {
                    return;
                }
                showCount--;

                let sdid = 'bz_' + item.id;
                if (followingsStatus[sdid] == 'disabled') {
                    return;
                }

                html += `<a class="avatar-item" title="${item.nickname}\r\n${item.title}\r\n${item.watchingCount}" href="${item.url}" target="_blank">`;
                html += `<img src="${item.avatar}" >`;
                html += `<div class="avatar-item-text">直播中</div>`;
                html += `</a>`;
            })
        }
        catch (e) {
            console.log(e);
        }
    }


    if (divLiving.innerHTML != html) {
        divLiving.innerHTML = html;
    }
}

function getFollowings() {
    Promise.all([
        chrome.runtime.sendMessage({ action: "getFollowings" }),
        chrome.runtime.sendMessage({ action: "getLiving" }),
        chrome.storage.local.get('followingsStatus')
    ]).then(([fls, liv, flsstatus]) => {
        if (chrome.runtime.lastError) {
            console.log(chrome.runtime.lastError);
        }

        let followingsStatus = flsstatus.followingsStatus || {};

        try {
            if (liv.living.dy && liv.living.dy.length > 0) {
                document.getElementsByName("tab_dy")[0].innerHTML = `抖音(${liv.living.dy.length})`;
            }
            else {
                document.getElementsByName("tab_dy")[0].innerHTML = `抖音`;
            }
        }
        catch (e) {
            console.log(e);
        }

        try {
            if (liv.living.ks && liv.living.ks.length > 0) {
                document.getElementsByName("tab_ks")[0].innerHTML = `快手(${liv.living.ks.length})`;
            }
            else {
                document.getElementsByName("tab_ks")[0].innerHTML = `快手`;
            }
        }
        catch (e) {
            console.log(e);
        }

        // 取虎牙开播数量
        try {
            let hyLivingCount = 0;
            !liv.living.hy || liv.living.hy.forEach(item => {
                if (item.iIsLive == 1) {
                    hyLivingCount++;
                }
            });

            if (hyLivingCount > 0) {
                document.getElementsByName("tab_hy")[0].innerHTML = `虎牙(${hyLivingCount})`;
            }
            else {
                document.getElementsByName("tab_hy")[0].innerHTML = `虎牙`;
            }
        }
        catch (e) {
            console.log(e);
        }

        // 取bilibili开播数量
        try {
            let bzLivingCount = 0;
            !liv.living.bz || liv.living.bz.forEach(item => {
                if (item.live_status == 1) {
                    bzLivingCount++;
                }
            });

            if (bzLivingCount > 0) {
                document.getElementsByName("tab_bz")[0].innerHTML = `B站(${bzLivingCount})`;
            }
            else {
                document.getElementsByName("tab_bz")[0].innerHTML = `B站`;
            }
        }
        catch (e) {
            console.log(e);
        }

        let dyOutLiving = [];
        let ksOutLiving = [];
        let hyOutLiving = [];
        let bzOutLiving = [];
        try {
            createDyList(fls.followings.dy ?? [], liv.living.dy ?? [], followingsStatus, dyOutLiving);
        }
        catch (e) {
            console.log(e);
        }
        try {
            createKsList(fls.followings.ks ?? [], liv.living.ks ?? [], followingsStatus, ksOutLiving);
        }
        catch (e) {
            console.log(e);
        }
        try {
            createHyList(fls.followings.hy ?? [], liv.living.hy ?? [], followingsStatus, hyOutLiving);
        }
        catch (e) {
            console.log(e);
        }
        try {
            createBzList(fls.followings.bz ?? [], liv.living.bz ?? [], followingsStatus, bzOutLiving);
        }
        catch (e) {
            console.log(e);
        }
        createHeaderLiving(followingsStatus, dyOutLiving, ksOutLiving, hyOutLiving, bzOutLiving);
    });
}

window.onload = function () {
    getFollowings();

    chrome.storage.local.get('followingsStatus', (result) => {
        const followingsStatus = result.followingsStatus || {};
        const msBtn = document.getElementById("main_switch");
        let ms = followingsStatus["mainSwitch"];

        if (ms == 'disabled') {
            msBtn.classList.remove('enabled');
            msBtn.classList.add('disabled');
            msBtn.textContent = '开启提示';
        }
        else {
            msBtn.classList.remove('disabled');
            msBtn.classList.add('enabled');
            msBtn.textContent = '已开启提示';
        }

        msBtn.addEventListener('click', () => {
            if (msBtn.classList.contains('disabled')) {
                msBtn.classList.remove('disabled');
                msBtn.classList.add('enabled');
                msBtn.textContent = '已开启提示';
                followingsStatus["mainSwitch"] = 'enabled';
            } else {
                msBtn.classList.remove('enabled');
                msBtn.classList.add('disabled');
                msBtn.textContent = '开启提示';
                followingsStatus["mainSwitch"] = 'disabled';
            }
            chrome.storage.local.set({ followingsStatus });
            chrome.runtime.sendMessage({ action: "refreshLivings" });
        });
    });

};

// 监听按钮点击事件
window.addEventListener('click', (evt) => {
    if (evt.target.name && evt.target.name.startsWith('tab_')) {
        openTab(evt.target, evt.target.name);
    }
});

function openTab(evt, tabName) {
    // 隐藏所有tab内容
    const tabContents = document.getElementsByClassName('tab-content');
    for (let i = 0; i < tabContents.length; i++) {
        tabContents[i].classList.remove('active');
    }

    // 去掉所有tab链接的活动状态
    const tabLinks = document.getElementsByClassName('tab-link');
    for (let i = 0; i < tabLinks.length; i++) {
        tabLinks[i].classList.remove('active');
    }

    // 显示当前tab内容，并添加活动状态到当前tab链接
    document.getElementById(tabName).classList.add('active');
    evt.classList.add('active');
}