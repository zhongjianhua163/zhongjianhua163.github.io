var lastData = Date.now();

let pt = '';
if (-1 != window.location.host.indexOf('douyin.com')) {
    pt = 'dy';
}
else if (-1 != window.location.host.indexOf('kuaishou.com')) {
    pt = 'ks';
}
else if (-1 != window.location.host.indexOf('huya.com')) {
    pt = 'hy';
}
else if (-1 != window.location.host.indexOf('bilibili.com')) {
    pt = 'bz';
}

function UpdateOrInsertAvatar(sdid, info, parent) {
    let avatar = document.getElementById(sdid);
    if (!avatar) {
        avatar = document.createElement('a');
        avatar.id = sdid;
        avatar.className = 'avatar-item';
        avatar.title = info.nickname + '\r\n' + info.title + '\r\n' + info.watchingCount;
        avatar.href = info.url;
        avatar.target = '_blank';

        let html = '';
        html = `<img src="${info.avatar}" >`;
        html += `<div class="avatar-item-text">直播中</div>`;

        avatar.innerHTML = html;
        parent.appendChild(avatar);
    }
    else {
        avatar.title = info.nickname + '\r\n' + info.title + '\r\n' + info.watchingCount;
        avatar.href = info.url;

        let avatarImg = avatar.getElementsByTagName('img')[0];
        if (avatarImg.src != info.avatar) {
            avatarImg.src = info.avatar;
        }
    }
}

function OnLinvingMsg(living) {
    chrome.runtime.sendMessage({ action: "storage", storage: "followingsStatus" }, (Response) => {
        let followingsStatus = Response.storage.followingsStatus || {};
        let divLiving = document.getElementById("divLiving");
        if (followingsStatus["mainSwitch"] == 'disabled') {
            divLiving.innerHTML = '';
            return;
        }

        let list = [];
        let ids = [];

        // 格式化抖音直播列表
        try {
            !living.dy || living.dy.forEach(item => {
                let sdid = 'dy_' + item.room.owner.sec_uid;
                if (followingsStatus[sdid] == 'disabled') {
                    return;
                }

                list.push({
                    id: sdid,
                    nickname: '抖音: ' + item.room.owner.nickname ?? '',
                    title: item.room.title ?? '',
                    watchingCount: item.room.room_view_stats.display_long_anchor ?? '',
                    url: 'https://live.douyin.com/' + item.web_rid ?? '',
                    avatar: item.room.owner.avatar_thumb.url_list[0] ?? ''
                });

                ids.push(sdid);
            });
        }
        catch (e) {
            console.log(e);
        }

        // 格式化快手直播列表
        try {
            !living.ks || living.ks.forEach(item => {
                let sdid = 'ks_' + item.author.id;
                if (followingsStatus[sdid] == 'disabled') {
                    return;
                }

                list.push({
                    id: sdid,
                    nickname: '快手: ' + item.author.name ?? '',
                    title: item.caption ?? '',
                    watchingCount: item.watchingCount ?? '',
                    url: 'https://live.kuaishou.com/u/' + item.author.id ?? '',
                    avatar: item.author.avatar
                });

                ids.push(sdid);
            })
        }
        catch (e) {
            console.log(e);
        }

        // 格式化虎牙直播列表
        try {
            !living.hy || living.hy.forEach(item => {
                if (item.iIsLive != 1) {
                    return;
                }

                let sdid = 'hy_' + item.lUid;
                if (followingsStatus[sdid] == 'disabled') {
                    return;
                }

                list.push({
                    id: sdid,
                    nickname: '虎牙: ' + item.sNick ?? '',
                    title: item.sLiveDesc ?? '',
                    watchingCount: item.iAttendeeCount + '人气',
                    url: 'https://www.huya.com/' + item.lUid,
                    avatar: item.sAvatar ?? ''
                });

                ids.push(sdid);
            });
        }
        catch (e) {
            console.log(e);
        }

        // 格式化b站直播列表
        try {
            !living.bz || living.bz.forEach(item => {
                if (item.live_status != 1) {
                    return;
                }

                let sdid = 'bz_' + item.uid;
                if (followingsStatus[sdid] == 'disabled') {
                    return;
                }

                list.push({
                    id: sdid,
                    nickname: 'B站: ' + item.uname ?? '',
                    title: item.title ?? '',
                    watchingCount: '',
                    url: 'https://live.bilibili.com/' + item.roomid,
                    avatar: item.face ?? ''
                });

                ids.push(sdid);
            })
        }
        catch (e) {
            console.log(e);
        }

        try {
            list.forEach(item => {
                UpdateOrInsertAvatar(item.id, item, divLiving);
            });
        }
        catch (e) {
            console.log(e);
        }

        // 遍历divLiving的子元素，如果不在ids中，则删除
        let children = divLiving.children;
        for (let i = 0; i < children.length; i++) {
            let child = children[i];
            if (child.id && ids.indexOf(child.id) == -1) {
                divLiving.removeChild(child);
            }
        }
    });
}

// 从内容脚本接收消息
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "living") {
        OnLinvingMsg(message.living);
        lastData = Date.now();
    }
    //console.log("onMessage:", message);
});

// 插入一个div
var div = document.createElement('div');
div.id = "divLiving";
div.className = 'avatar-list';
if (pt == 'ks') {
    div.style.left = '640px';
    div.style.transform = "scale(0.4)";
}
else if (pt == 'hy') {
    div.style.left = '50px';
    div.style.top = '58px';
    div.style.flexDirection = 'column';
}
else if (pt == 'bz') {
    if (window.location.host.indexOf('live.') != -1) {
        div.style.left = '120px';
        div.style.top = '88px';
    }
    else {
        div.style.left = '52px';
        div.style.top = '186px';
    }

    div.style.flexDirection = 'column';
}
document.body.appendChild(div);

chrome.runtime.sendMessage({ action: 'getLiving' }, (Response) => {
    OnLinvingMsg(Response.living);
});

setInterval(() => {
    // 如果lastData 距离现在超过1分钟，则将divLiving的底色置为灰色,否则删除底色
    if (Date.now() - lastData > 60000) {
        if (div.style.backgroundColor != "dimgrey") {
            div.style.backgroundColor = "dimgrey";
            div.title = "服务未启动!";
        }
    } else {
        if (div.style.backgroundColor != "") {
            div.style.backgroundColor = "";
            div.title = "";
        }
    }

    try {
        chrome.runtime.sendMessage({ action: 'hi' });
    }
    catch (e) { }
}, 1000);
